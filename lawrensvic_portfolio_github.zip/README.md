# Lawrensvic M. Arangel — Personal Portfolio

A responsive single-page portfolio website created from the information in `StudentProfile.html` and the visual style of `home.css`.

## Files

- `index.html` — GitHub Pages entry point
- `style.css` — portfolio styling
- `README.md` — project notes

## Run locally

Open `index.html` in a browser.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the branch containing `index.html` (usually `main`) and `/root`.
6. Save and wait for GitHub Pages to publish the site.

The source profile contains local image references such as `Pics/img1.jpg`. This portfolio intentionally uses a CSS profile placeholder so the site works immediately without those missing image files. If you want to use your real profile photo, replace the placeholder in `index.html` with your image and upload the image into the repository.
